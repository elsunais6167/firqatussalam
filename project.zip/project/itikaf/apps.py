from django.apps import AppConfig


class ItikafConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'itikaf'
